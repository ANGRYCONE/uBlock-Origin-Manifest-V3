chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (
    changeInfo.status === "complete" &&
    tab.url &&
    !tab.url.startsWith("chrome://") &&
    !tab.url.startsWith("chrome-extension://") &&
    !tab.url.startsWith("devtools://") &&
    !tab.url.startsWith("edge://") &&
    !tab.url.startsWith("about:") &&
    !tab.url.startsWith("file://") &&
    !tab.url.includes("chrome-error://")
  ) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        document.documentElement.innerHTML = `
          <div style="display:flex; flex-direction: column; justify-content:center; align-items:center; height:100vh; background:#111; color:#eee; font-family: Arial, sans-serif;">
            <h1 style="font-size:120px; margin:0;">SIKE</h1>
            <p style="font-size:18px; margin-top:10px;">
              This page was taken over by <a href="https://github.com/ANGRYCONE/uBlock-Origin-Manifest-V3" target="_blank" style="color:#4CAF50; text-decoration:none;">https://github.com/ANGRYCONE/uBlock-Origin-Manifest-V3</a>
            </p>
          </div>`;
      }
    }).catch(() => {});
  }
});
